/*
 * Simple interactivity for the Ludilo Mowers site.
 *
 * - Filters products on the products page based on the text entered in the
 *   search box.  Each product card defines a data-name attribute which is
 *   compared against the search query.
 * - Handles submission of the contact form by showing a friendly message and
 *   resetting the form.  In a real application this is where you would
 *   perform an AJAX request to your server.
 */

document.addEventListener('DOMContentLoaded', () => {
  // Product search filtering
  const searchInput = document.getElementById('searchInput');
  const productGrid = document.getElementById('productGrid');
  if (searchInput && productGrid) {
    const cards = productGrid.querySelectorAll('.product-card');
    searchInput.addEventListener('input', () => {
      const value = searchInput.value.toLowerCase().trim();
      cards.forEach(card => {
        const name = card.getAttribute('data-name').toLowerCase();
        if (name.includes(value)) {
          card.style.display = '';
        } else {
          card.style.display = 'none';
        }
      });
    });
  }

  // Contact form submission
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', evt => {
      evt.preventDefault();
      alert('Hvala na vašoj poruci! Javiti ćemo vam se uskoro.');
      contactForm.reset();
    });
  }
});